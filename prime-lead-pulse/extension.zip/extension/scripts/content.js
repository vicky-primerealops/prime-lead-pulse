// ============================================================
// Prime Lead Pulse — Gmail Content Script (v2)
// Features:
//  1. Inject "Track this email" toggle in compose window
//  2. Intercept Send to embed pixel + rewrite links
//  3. Sent folder: inject "Untracked / Opened Nx / Clicked Nx" badges
//  4. Email view: inject right-side panel with Opens, Clicks, Timeline
//  5. Thread view: inject "View Activity (N)" button
// ============================================================

const PRIME_STYLE_ID = 'prime-lead-pulse-styles';

// ------ Inject global CSS once ------
if (!document.getElementById(PRIME_STYLE_ID)) {
  const style = document.createElement('style');
  style.id = PRIME_STYLE_ID;
  style.textContent = `
    .plp-badge {
      display: inline-flex;
      align-items: center;
      padding: 2px 8px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 600;
      margin-right: 6px;
      white-space: nowrap;
    }
    .plp-badge-untracked { background: #f3f4f6; color: #6b7280; }
    .plp-badge-opened { background: #d1fae5; color: #065f46; }
    .plp-badge-clicked { background: #c7d2fe; color: #3730a3; }

    .plp-panel {
      position: fixed;
      top: 60px;
      right: 0;
      width: 320px;
      height: calc(100vh - 60px);
      background: #fff;
      border-left: 1px solid #e5e7eb;
      box-shadow: -4px 0 16px rgba(0,0,0,0.08);
      z-index: 9999;
      display: flex;
      flex-direction: column;
      font-family: 'Google Sans', Arial, sans-serif;
      font-size: 13px;
    }
    .plp-panel-header {
      padding: 14px 16px;
      border-bottom: 1px solid #e5e7eb;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .plp-panel-title { font-weight: 600; color: #111827; font-size: 14px; }
    .plp-panel-close {
      cursor: pointer;
      color: #9ca3af;
      font-size: 18px;
      line-height: 1;
      border: none;
      background: none;
      padding: 0 2px;
    }
    .plp-panel-close:hover { color: #374151; }
    .plp-panel-meta { padding: 12px 16px; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-size: 12px; }
    .plp-panel-stats {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 8px;
      padding: 12px 16px;
      border-bottom: 1px solid #f3f4f6;
    }
    .plp-stat-box {
      background: #f9fafb;
      border-radius: 10px;
      padding: 10px 8px;
      text-align: center;
    }
    .plp-stat-num { font-size: 22px; font-weight: 700; color: #111827; }
    .plp-stat-label { font-size: 10px; color: #9ca3af; text-transform: uppercase; letter-spacing: 0.5px; }
    .plp-status-badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 600;
    }
    .plp-status-opened { background: #d1fae5; color: #065f46; }
    .plp-status-clicked { background: #c7d2fe; color: #3730a3; }
    .plp-status-untracked { background: #f3f4f6; color: #6b7280; }
    .plp-timeline-title {
      padding: 12px 16px 6px;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #6b7280;
    }
    .plp-timeline-scroll { overflow-y: auto; flex: 1; padding: 0 16px 16px; }
    .plp-timeline-item {
      display: flex;
      align-items: flex-start;
      gap: 10px;
      padding: 8px 0;
      border-bottom: 1px solid #f9fafb;
    }
    .plp-event-icon {
      width: 26px;
      height: 26px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      font-size: 13px;
    }
    .plp-event-open { background: #eff6ff; }
    .plp-event-click { background: #f0fdf4; }
    .plp-event-text { flex: 1; }
    .plp-event-label { font-weight: 500; color: #374151; }
    .plp-event-time { font-size: 11px; color: #9ca3af; margin-top: 1px; }
    .plp-event-url { font-size: 11px; color: #6366f1; margin-top: 3px; word-break: break-all; }
    .plp-view-btn {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 10px;
      border-radius: 999px;
      background: #eff6ff;
      color: #3b82f6;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      border: none;
      margin-left: 8px;
    }
    .plp-view-btn:hover { background: #dbeafe; }
  `;
  document.head.appendChild(style);
}

// ------ State ------
let emailCache = []; // [{id, subject, recipient, sender_email, opens, clicks, status, events}]
let panelEmailId = null;

// ------ Helpers ------
function formatEventTime(iso) {
  return new Date(iso).toLocaleString('en-US', {
    month: 'short', day: 'numeric',
    hour: 'numeric', minute: '2-digit',
  });
}

function getActiveSenderEmail() {
  // Try to get from profile icon aria-label (e.g. "Google Account: Vicky (vicky@diyflatfee.com)")
  const accountBtn = document.querySelector('a[aria-label*="Google Account"]');
  if (accountBtn) {
    const match = accountBtn.getAttribute('aria-label').match(/\(([^)]+@[^)]+)\)/);
    if (match) return match[1];
  }
  // Fallback: extract u/N from URL
  const urlMatch = location.pathname.match(/\/u\/(\d+)\//);
  return urlMatch ? `account_${urlMatch[1]}` : null;
}

function findEmailBySubject(subject) {
  if (!subject) return null;
  const norm = s => s.toLowerCase().replace(/\s+/g, ' ').trim();
  const normSubj = norm(subject);
  // Try exact match first
  let match = emailCache.find(e => norm(e.subject) === normSubj);
  // If no exact match, try prefix match (Gmail often appends " - body snippet" to list view subjects)
  if (!match) {
    match = emailCache.find(e => normSubj.startsWith(norm(e.subject)));
  }
  return match || null;
}

// ------ API Calls via background ------
async function fetchEmailStats(senderEmail) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action: 'GET_STATS', senderEmail }, response => {
      if (response && response.success) {
        // Build enriched cache
        emailCache = response.data.emails.map(email => {
          const opens = (email.tracking_events || []).filter(e => e.event_type === 'open');
          const clicks = (email.tracking_events || []).filter(e => e.event_type === 'click');
          let status = 'Untracked';
          if (clicks.length > 0) status = 'Clicked';
          else if (opens.length > 0) status = 'Opened';
          return { ...email, opens: opens.length, clicks: clicks.length, status, events: email.tracking_events || [] };
        });
      } else {
        console.error('Prime Lead Pulse: Failed to fetch stats.', response?.error);
      }
      resolve(); // Always resolve so UI still initializes
    });
  });
}

// ------ Sent Folder Badge Injection ------
function injectSentBadges() {
  const emailRows = document.querySelectorAll('tr.zA');
  emailRows.forEach(row => {
    // Check if badge physically exists instead of dataset, because Gmail recycles DOM nodes
    if (row.querySelector('.plp-badge')) return;

    // Prefer innermost spans to avoid picking up body snippets in the subject line
    const subjectEl = row.querySelector('span[data-thread-id], span.bqe, .bog');
    if (!subjectEl) return;

    // We no longer split by ' - ' because findEmailBySubject handles prefix matching perfectly!
    let subject = subjectEl.textContent.trim();
    
    const record = findEmailBySubject(subject);

    const badge = document.createElement('span');
    badge.className = 'plp-badge';
    badge.dataset.plpBadge = 'true';

    if (!record) {
      badge.className += ' plp-badge-untracked';
      badge.textContent = 'Untracked';
    } else if (record.clicks > 0) {
      badge.className += ' plp-badge-clicked';
      badge.textContent = `Clicked ${record.clicks}x`;
    } else if (record.opens > 0) {
      badge.className += ' plp-badge-opened';
      badge.textContent = `Opened ${record.opens}x`;
    } else {
      badge.className += ' plp-badge-unopened';
      badge.textContent = 'Unopened';
    }

    const senderEl = row.querySelector('.yW');
    if (senderEl) {
      // Insert inside the .yW container so it doesn't break table cell layouts
      senderEl.insertBefore(badge, senderEl.firstChild);
    } else {
      subjectEl.parentElement.insertBefore(badge, subjectEl);
    }

    badge.style.cursor = 'pointer';
    badge.onclick = (e) => {
      e.stopPropagation(); // prevent Gmail from opening the email
      
      // Extract basic info from the list view row for the panel
      let to = 'Unknown';
      if (senderEl) {
        const clone = senderEl.cloneNode(true);
        const b = clone.querySelector('.plp-badge');
        if (b) b.remove();
        to = clone.textContent.trim();
      }
      
      const dateEl = row.querySelector('.xW.xY span');
      const sentDate = dateEl ? dateEl.getAttribute('title') || dateEl.textContent : '';
      
      showPanel(record, subject, to, sentDate);
    };
  });
}

// ------ Right-Side Activity Panel ------
function removePanel() {
  const existing = document.getElementById('plp-panel');
  if (existing) existing.remove();
  panelEmailId = null;
}

function showPanel(record, subject, to, sentDate) {
  removePanel();
  if (!record) return;
  panelEmailId = record.id;

  const panel = document.createElement('div');
  panel.id = 'plp-panel';
  panel.className = 'plp-panel';

  const statusClass = record.status === 'Clicked' ? 'plp-status-clicked'
    : record.status === 'Opened' ? 'plp-status-opened' : 'plp-status-untracked';

  const eventsHtml = [...record.events]
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .map(ev => {
      const isOpen = ev.event_type === 'open';
      return `
        <div class="plp-timeline-item">
          <div class="plp-event-icon ${isOpen ? 'plp-event-open' : 'plp-event-click'}">
            ${isOpen ? '👁️' : '🔗'}
          </div>
          <div class="plp-event-text">
            <div class="plp-event-label">${isOpen ? 'Opened email' : 'Clicked link'}</div>
            <div class="plp-event-time">${formatEventTime(ev.created_at)}</div>
            ${!isOpen && ev.url ? `<div class="plp-event-url">${ev.url}</div>` : ''}
          </div>
        </div>
      `;
    }).join('');

  panel.innerHTML = `
    <div class="plp-panel-header">
      <span class="plp-panel-title">${subject || 'Email Details'}</span>
      <button class="plp-panel-close" id="plp-close-btn">✕</button>
    </div>
    <div class="plp-panel-meta">
      <div>To: ${to || record.recipient || ''}</div>
      ${sentDate ? `<div>Sent: ${sentDate}</div>` : ''}
    </div>
    <div class="plp-panel-stats">
      <div class="plp-stat-box">
        <div class="plp-stat-num">${record.opens}</div>
        <div class="plp-stat-label">Opens</div>
      </div>
      <div class="plp-stat-box">
        <div class="plp-stat-num">${record.clicks}</div>
        <div class="plp-stat-label">Clicks</div>
      </div>
      <div class="plp-stat-box" style="display:flex;align-items:center;justify-content:center;">
        <span class="plp-status-badge ${statusClass}">${record.status}</span>
      </div>
    </div>
    <div class="plp-timeline-title">Activity Timeline</div>
    <div class="plp-timeline-scroll">${eventsHtml || '<div style="color:#9ca3af;padding:16px 0;text-align:center;">No activity yet</div>'}</div>
  `;

  document.body.appendChild(panel);
  document.getElementById('plp-close-btn').addEventListener('click', removePanel);
}

// ------ Detect open email and inject View Activity button ------
function injectEmailViewFeatures() {
  // Check if we're viewing a single email
  const subjectEl = document.querySelector('h2.hP');
  if (!subjectEl) return;

  const subject = subjectEl.textContent.trim();
  const record = findEmailBySubject(subject);

  // We NO LONGER auto-open the panel here. The user must click the Pill or the "View Activity" button.
  if (!record) {
    removePanel();
  }

  // Inject "View Activity (N)" button in thread view
  const dateRows = document.querySelectorAll('.g3');
  dateRows.forEach(dateEl => {
    if (dateEl.dataset.plpBtn) return;
    if (!record) return;
    const total = record.opens + record.clicks;
    const btn = document.createElement('button');
    btn.className = 'plp-view-btn';
    btn.textContent = `View Activity (${total})`;
    btn.onclick = (e) => {
      e.stopPropagation();
      const to = document.querySelector('.gD')?.getAttribute('email') || '';
      showPanel(record, subject, to, '');
    };
    dateEl.parentElement.insertBefore(btn, dateEl.nextSibling);
    dateEl.dataset.plpBtn = 'true';
  });
}

// ------ Compose Window Injection ------
function injectComposeTool(composeWindow) {
  if (composeWindow.dataset.plpInjected) return;

  const sendBtn = composeWindow.querySelector('div[aria-label^="Send"]');
  if (!sendBtn) return; 

  // Find the table that contains the bottom toolbar
  const bottomTable = sendBtn.closest('table');
  if (!bottomTable) return;

  composeWindow.dataset.plpInjected = 'true';

  // Create a completely separate row (div) for our tools
  const container = document.createElement('div');
  container.style.cssText = 'display:flex;align-items:center;padding:8px 12px;background:#f8fafc;border-top:1px solid #e2e8f0;border-bottom:1px solid #e2e8f0;gap:16px;margin-bottom:4px;border-radius:4px;';

  // "Use Template" Button
  const tplBtn = document.createElement('div');
  tplBtn.style.position = 'relative';
  tplBtn.innerHTML = `<button type="button" style="display:inline-flex;align-items:center;gap:6px;background:white;border:1px solid #cbd5e1;color:#334155;font-size:12px;font-weight:600;cursor:pointer;padding:6px 12px;border-radius:16px;box-shadow:0 1px 2px rgba(0,0,0,0.05);" onmouseover="this.style.background='#f1f5f9'" onmouseout="this.style.background='white'">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg>
    Use Template
  </button>`;
  
  const dropdown = document.createElement('div');
  dropdown.style.cssText = 'display:none;position:absolute;bottom:100%;left:0;margin-bottom:8px;background:white;border:1px solid #e2e8f0;border-radius:8px;box-shadow:0 10px 15px -3px rgba(0,0,0,0.1);width:250px;max-height:300px;overflow-y:auto;z-index:999;';
  tplBtn.appendChild(dropdown);

  tplBtn.querySelector('button').onclick = () => {
    if (dropdown.style.display === 'block') {
      dropdown.style.display = 'none';
      return;
    }
    dropdown.innerHTML = '<div style="padding:12px;text-align:center;color:#64748b;font-size:12px;">Loading templates...</div>';
    dropdown.style.display = 'block';
    
    chrome.runtime.sendMessage({ action: 'GET_TEMPLATES' }, response => {
      if (!response || !response.success) {
        dropdown.innerHTML = '<div style="padding:12px;color:#ef4444;font-size:12px;">Error loading templates</div>';
        return;
      }
      if (response.data.templates.length === 0) {
        dropdown.innerHTML = '<div style="padding:12px;text-align:center;color:#64748b;font-size:12px;">No templates found. Create one in the dashboard.</div>';
        return;
      }
      dropdown.innerHTML = '';
      response.data.templates.forEach(tpl => {
        const item = document.createElement('div');
        item.style.cssText = 'padding:10px 12px;border-bottom:1px solid #f1f5f9;cursor:pointer;font-size:13px;color:#0f172a;';
        item.textContent = tpl.name;
        item.onmouseover = () => item.style.background = '#f8fafc';
        item.onmouseout = () => item.style.background = 'white';
        item.onclick = () => {
          const subjInput = composeWindow.querySelector('input[name="subjectbox"]');
          if (subjInput) subjInput.value = tpl.subject || '';
          const bodyDiv = composeWindow.querySelector('div[contenteditable="true"]');
          if (bodyDiv) bodyDiv.innerHTML = (tpl.body || '').replace(/\n/g, '<br/>') + '<br/><br/>' + bodyDiv.innerHTML;
          dropdown.style.display = 'none';
        };
        dropdown.appendChild(item);
      });
    });
  };

  document.addEventListener('click', (e) => {
    if (!tplBtn.contains(e.target)) dropdown.style.display = 'none';
  });

  // "Best Time" Button
  const timeBtn = document.createElement('div');
  timeBtn.innerHTML = `<button type="button" style="display:inline-flex;align-items:center;gap:6px;background:#fef3c7;border:1px solid #fde68a;color:#92400e;font-size:12px;font-weight:600;cursor:pointer;padding:6px 12px;border-radius:16px;box-shadow:0 1px 2px rgba(0,0,0,0.05);" onmouseover="this.style.background='#fde68a'" onmouseout="this.style.background='#fef3c7'">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
    Best Time
  </button>`;
  timeBtn.onclick = () => window.open('https://prime-lead-pulse.vercel.app/dashboard/calendar', '_blank', 'width=800,height=600');

  // Track Checkbox (styled like a toggle)
  const trackWrapper = document.createElement('div');
  trackWrapper.style.cssText = 'display:inline-flex;align-items:center;gap:6px;background:#dcfce7;border:1px solid #bbf7d0;padding:6px 12px;border-radius:16px;cursor:pointer;';
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.className = 'prime-track-checkbox';
  checkbox.checked = true;
  checkbox.id = `plp-chk-${Date.now()}`;
  checkbox.style.cssText = 'cursor:pointer;accent-color:#16a34a;';
  const label = document.createElement('label');
  label.htmlFor = checkbox.id;
  label.innerHTML = '<span style="color:#16a34a;font-weight:bold;margin-right:4px;">●</span>Track Opens';
  label.style.cssText = 'font-size:12px;color:#166534;font-weight:600;cursor:pointer;user-select:none;';
  trackWrapper.onclick = (e) => {
    if (e.target !== checkbox) checkbox.checked = !checkbox.checked;
  };
  trackWrapper.appendChild(checkbox);
  trackWrapper.appendChild(label);

  container.appendChild(tplBtn);
  container.appendChild(timeBtn);
  container.appendChild(trackWrapper);
  
  // Insert our new row precisely above the bottom formatting table
  bottomTable.parentElement.insertBefore(container, bottomTable);
}

// ------ Send Interception ------
document.addEventListener('click', async (e) => {
  const isSend = e.target.closest('div[aria-label^="Send"]') ||
    e.target.closest('.T-I.J-J5-Ji.aoO.v7.T-I-atl.L3');
  if (!isSend) return;

  const compose = e.target.closest('div[role="dialog"], .M9');
  if (!compose) return;

  const checkbox = compose.querySelector('.prime-track-checkbox');
  if (!checkbox || !checkbox.checked) return;

  e.preventDefault();
  e.stopPropagation();

  const btn = isSend.closest('[role="button"]') || isSend;
  btn.style.opacity = '0.5';
  btn.style.pointerEvents = 'none';

  const senderEmail = getActiveSenderEmail() || 'unknown';
  const chipElements = Array.from(compose.querySelectorAll('[data-hovercard-id]'));
  let recipientList = [...new Set(chipElements.map(el => el.getAttribute('data-hovercard-id')).filter(Boolean))];
  let recipient = recipientList.join(', ');
  
  if (!recipient) {
    const legacyChips = Array.from(compose.querySelectorAll('div[email]'));
    let legacyList = [...new Set(legacyChips.map(c => c.getAttribute('email')).filter(Boolean))];
    recipient = legacyList.join(', ');
  }
  if (!recipient) {
    recipient = compose.querySelector('input[name="to"]')?.value || 'Unknown Recipient';
  }
  const subject = compose.querySelector('input[name="subjectbox"]')?.value ?? 'No Subject';

  chrome.runtime.sendMessage({
    action: 'CREATE_EMAIL',
    payload: { sender_email: senderEmail, recipient, subject }
  }, response => {
    if (response?.success) {
      const { email } = response.data;
      chrome.storage.local.get(['apiUrl'], ({ apiUrl }) => {
        const base = (apiUrl || '').replace(/\/$/, '');
        const body = compose.querySelector('div[aria-label="Message Body"]');
        if (body) {
          const pixel = document.createElement('img');
          pixel.src = `${base}/api/track/pixel/${email.id}`;
          pixel.width = 1; pixel.height = 1; pixel.style.display = 'none';
          body.appendChild(pixel);

          body.querySelectorAll('a').forEach(a => {
            if (!a.href.startsWith('mailto:')) {
              a.href = `${base}/api/track/link/${email.id}?url=${encodeURIComponent(a.href)}`;
            }
          });
        }
        checkbox.checked = false;
        btn.style.opacity = '1'; btn.style.pointerEvents = 'auto';
        btn.click();
      });
    } else {
      alert('Prime Lead Pulse: Failed to track. Please check you are logged in.');
      btn.style.opacity = '1'; btn.style.pointerEvents = 'auto';
    }
  });
}, true);

// ------ Master MutationObserver ------
let statsTimeout = null;
const observer = new MutationObserver(() => {
  // 1. Compose windows (popouts and inline replies) need instant injection
  document.querySelectorAll('div[role="dialog"], .M9').forEach(injectComposeTool);

  // 2. Refresh the UI instantly using current cache
  clearTimeout(statsTimeout);
  statsTimeout = setTimeout(() => {
    injectSentBadges();
    injectEmailViewFeatures();
  }, 150); // fast UI refresh
});

observer.observe(document.body, { childList: true, subtree: true });

// ------ Instant Notifications Loop ------
// Wake up the background worker and update stats every 3 seconds!
setInterval(() => {
  chrome.runtime.sendMessage({ action: 'CHECK_NOTIFICATIONS' });
  const senderEmail = getActiveSenderEmail();
  fetchEmailStats(senderEmail).then(() => {
    injectSentBadges();
    injectEmailViewFeatures();
  });
}, 3000);

// Initial load
const senderEmail = getActiveSenderEmail();
fetchEmailStats(senderEmail).then(() => {
  injectSentBadges();
  injectEmailViewFeatures();
});

console.log('Prime Lead Pulse: Content script v2 loaded.');
